<?php
$FILE = str_replace('\\', '/', dirname(__FILE__));
define("ROUTE", str_replace('/Home', '', $FILE));
define("X_ADMIN", false);
define("EDITION", array('banhao' => '6.0.1', 'shijian' => '2021-03-15',));
define("XDZS", "新导助手：http://zzzs.xingdaoo.com/，");
define("X_URL", $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/');
define("X_STATIC", "/Public/xindaozhushou/");
define("X_PLUGIN_STATIC", X_STATIC . "static/");

if(strripos(ROUTE, '/Action') != strlen(ROUTE) - 7){
	exit('获取文件路径失败');
}

class Xindaozhushou extends HomeAction{

	private $Allclass;

	// 初始化
	public function __construct(){
		parent::__construct();
		require_once(ROUTE . "/xindaozhushou/model/Allclass.php");
		$this->Allclass = new Allclass();
		define("TONGJI", $this->Allclass->tongji());
		print_r(TONGJI);
	}

	// 插件
	public function plugin(){
		$pluginid = $this->saddslashes($_GET['pluginid']);
		$mod = empty($_GET['mod']) ? 'index' : $this->saddslashes($_GET['mod']);
		define("PLUGIN_DIR", ROUTE . '/xindaozhushou/plugin/' . $pluginid . '/');
		$plugin_file = PLUGIN_DIR . $mod . '.php';
		if(is_file($plugin_file)){
			include $plugin_file;
		}else{
			$this->r_json('没有安装' . $pluginid . '插件，或者插件某个文件不存在', 1);
		}
	}

	protected function r_json($msg = '', $code = 1, $data = null){

		if($msg || $data || $code = 0){
			echo json_encode(array(
				'code' => $code,
				'msg' => $msg,
				'data' => $data
			));
		}else{
			echo '{"code": '. $code .'}';
		}
	}

    protected function saddslashes($string, $force = 0){
        return $this->Allclass->saddslashes($string, $force);
    }

    protected function shtmlspecialchars($string) {
        return $this->Allclass->shtmlspecialchars($string);
    }

    protected function sintval($str) {
		return $this->Allclass->sintval($str);
    }

	// 加载配置文件
	private function loadconf($path){
		$path = $this->saddslashes($path);
		$path = ROUTE . '/xindaozhushou/config/' . $path .'.php';
		if (is_file($path)) {
			$config = include($path);
			if(is_array($config)){
				return $this->shtmlspecialchars($config);
			}
		}
		return array();
	}

	// 加载插件配置
	protected function loadconf_plugin($path, $zhushou = false){
		if(strpos($path, ':')){
			$path = str_replace(':', '/', $path);
		}else{
			if($zhushou){
				$path = $path;
			}else{
				$path = $path . "/config";
			}
		}
		return $this->loadconf($path);
	}

	// 更新配置
	private function loadupdate($path, $data){
		$path = $this->saddslashes($path);
		$dir = ROUTE . '/xindaozhushou/config/';
		$path = $dir . $path . ".php";
		$data = $this->shtmlspecialchars($data);
		$data = $this->saddslashes($data);
		$str = "<?php\nreturn array(\n";
		$str .= $this->arr2str($data);
		$str .= ");";
		if (file_put_contents($path, $str)) {
			return true;
		} else {
			return false;
		}
	}

	// 更新插件配置
	protected function loadupdate_plugin($path, $data){
		if(!$path){
			return false;
		}
		$dir = ROUTE . '/xindaozhushou/config/';
		if(strpos($path, ':')){
			$dir .= explode(":", $path)[0];
			$path = str_replace(':', '/', $path);
		}else{ 
			$path .= '/config'; // 默认插件配置文件
		}
		if (!is_dir($dir)) {
			mkdir(iconv("UTF-8", "GBK", $dir), 0777, true);
		}
		return $this->loadupdate($path, $data);
	}

    // 数组转字符串
    protected function arr2str($arr, $t = 1){
        return $this->Allclass->arr2str($arr, $t); 
	}
	
	protected function str_md5($length = 16){
        return $this->Allclass->str_md5($length);
	}
}
class XndaozhushouAction extends Xindaozhushou{}
?>