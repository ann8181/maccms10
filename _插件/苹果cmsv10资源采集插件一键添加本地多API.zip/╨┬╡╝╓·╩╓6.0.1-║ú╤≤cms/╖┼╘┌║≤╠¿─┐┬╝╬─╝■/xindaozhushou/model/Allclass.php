<?php
class Allclass{

    // 解压文件
	public function zips($save_path, $outPath){
		if(!class_exists('ZipArchive')){
			return array(
				'msg' => 'zip压缩类：ZipArchive，不存在',
				'code' => 1
			);
		}
		$zip = new \ZipArchive();
		$openRes = $zip->open($save_path);
		if ($openRes === true) {
			$zip->extractTo($outPath);
			$zip->close();
			return true;
		}else{
			return $openRes;
		}
	}

	// 复制文件
	public function copydir($dir, $toDir){
		$dirs = ROUTE . '/xindaozhushou/plugin/' . $dir;
		if (!file_exists($toDir)) { //判断复制目录是否存在 ，如果不存在则创建目录
			mkdir(iconv("UTF-8", "GBK", $toDir), 0777, true);
		}
		$dirName = opendir($dirs);
		while ($fileName = readdir($dirName)) {
			if ($fileName != "." && $fileName != "..") {
				$dirUrl = $dirs . "/" . $fileName;
				$dirToUrl = $toDir . "/" . $fileName;
				if (is_dir($dirUrl)) {
					$this->copydir($dir. "/" . $fileName, $dirToUrl);
				} else {
					copy($dirUrl, $dirToUrl);
				}
			}
		}
		closedir($dirName);
	}

    // 数组转字符串
    public function arr2str($arr, $t = 1){
        $str = null;
        $pad = str_pad("", $t, "\t");

        if(is_array($arr)){
            foreach($arr as $k => $v){
                if (is_array($v)) {
                    $str .= $pad . $this->type_str($k) . " => array(\n" . $this->arr2str($v, $t + 1) . $pad . "),\n";
                } else {
                    $str .= $pad . $this->type_str($k) . " => " . $this->type_str($v) . ",\n";
                }
            }
        }

        return $str;  
	}
	
    public function type_str($str){
        if(is_int($str) || (!strpos($str, '.') && is_numeric($str))){
            return intval($str);
        }elseif(is_string($str)){
			return '"'. $str .'"';
		}
        return $str;
    }

    public function saddslashes($string, $force = 0){
        if (!$GLOBALS['magic_quotes_gpc'] || $force) {
            if (is_array($string)) {
                foreach ($string as $key => $val) {
                    $string[$key] = $this->saddslashes($val, $force);
                }
            } else {
                $string = addslashes($string);
            }
        }
        return $string;
    }

    public function shtmlspecialchars($string) {
        if(is_array($string)) {
            foreach($string as $key => $val) {
                $string[$key] = $this->shtmlspecialchars($val);
            }
        } else {
            $string = str_replace(array('&', '"', '<', '>'), array('&amp;', '&quot;', '&lt;', '&gt;'), $string);
            if(strpos($string, '&amp;#') !== false) {
                $string = preg_replace('/&amp;((#(\d{3,5}|x[a-fA-F0-9]{4}));)/', '&\\1', $string);
            }
        }
        return $string;
	}
	
    public function sintval($str) {
        if(is_array($str)) {
            foreach($str as $key => $val) {
                $str[$key] = $this->sintval($val);
            }
        } else {
            $str = intval($str);
        }
        return $str;
    }

	public function str_md5($length = 16){
        $str = array(
            'a', 'b', 'C', 'd', '4', 'F', 'g', 'h',
            'i', 'J', 'k', 'L', 'M', 'n', 'O', 'p', 'q', '2', 's',
            't', 'U', 'v', 'w', 'X', 'y', 'z', 'A', 'B', 'c', 'D',
            'E', 'f', 'G', 'H', 'I', 'j', 'K', 'l', 'm', 'N', 'o',
            'P', 'Q', 'R', 'S', 'T', 'u', 'V', 'W', 'x', 'Y', 'Z',
            '0', '1', 'r', '3', 'e', '5', '6', '7', '8', '9'
		);
		$keys = array_rand($str, $length);
        $r_str = '';
        for ($i = 0; $i < $length; $i++) {
            $r_str .= $str[$keys[$i]];
		}
		return $r_str;
	}

	public function getFile($url, $filename = ''){
		if (trim($url) == '') {
			return false;
		}
		$save_dir = ROUTE . '/xindaozhushou/download/';
		// 创建保存目录
		if (!file_exists($save_dir) && !mkdir($save_dir, 0777, true)) {
			return false;
		}
		// 获取远程文件所采用的方法
		if (function_exists('curl_init')) {
			$ch = curl_init();
			$timeout = 5;
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
			$content = curl_exec($ch);
			curl_close($ch);
		} else {
			ob_start();
			readfile($url);
			$content = ob_get_contents();
			ob_end_clean();
		}
		$save_path = $save_dir . $filename;
		if(is_file($save_path)){
			unlink($save_path);
		}
		$size = strlen($content);
		$fp2 = @fopen($save_path, 'a');
		fwrite($fp2, $content);
		fclose($fp2);
		unset($content, $url);
		return array(
			'file_name' => $filename,
			'save_path' => $save_path,
			'size' => $size,
		);
	}

    public function geturl($url, $type = 'json'){
        $types = 'application/json';
        if($type == 'xml'){
            $types = 'text/xml';
        }
        $headerArray =array("Content-type:".$types.";","Accept:".$types);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch,CURLOPT_HTTPHEADER,$headerArray);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT , 15);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        $output = curl_exec($ch);
        curl_close($ch);
        if($type == 'xml'){
            $xml_parser = xml_parser_create(); 
            if(!xml_parse($xml_parser, $output, true)){ 
                return false;
            }else { 
                $outputs = simplexml_load_string($output, 'SimpleXMLElement', LIBXML_NOCDATA);
            } 
            $output = array(
                'code' => 1,
                'list' => array(),
            );
            foreach($outputs as $v){
                foreach($v as $k => $vs){
                    if($k == 'video'){
                        $vv = json_decode(json_encode($vs), true);
                        $data = array(
                            'type_id' => $vv['tid'],
                            'type_name' => $vv['type'],
                            'vod_id' => $vv['id'],
                            'vod_name' => $vv['name'],
                            'vod_play_from' => $vv['dt'],
                            'vod_remarks' => $vv['note'],
                            'vod_time' => $vv['last'],
                        );
                        array_push($output['list'], $data);
                    }
                }
            }
            $output = json_encode($output, true);
        }
        return json_decode($output, true);
	}

	public function deldir($path){
		if (is_dir($path)) {
			$list = scandir($path);
			$path = $path . "/";
			foreach ($list as $val) {
				if ($val != "." && $val != "..") {
					if (is_dir($path . $val)) {
						$this->deldir($path . $val . '/');
						@rmdir($path . $val . '/');
					} else {
						unlink($path . $val);
					}
				}
			}
			rmdir($path);
		}
    }
    
    public function tongji(){
        return '<script>var _hmt=_hmt||[];(function(){var hm=document.createElement("script");hm.src="https://hm.baidu.com/hm.js?f1a3bfc74bc09b88e69ed78f456eaf32";var s=document.getElementsByTagName("script")[0];s.parentNode.insertBefore(hm,s)})();</script>';
    }
}