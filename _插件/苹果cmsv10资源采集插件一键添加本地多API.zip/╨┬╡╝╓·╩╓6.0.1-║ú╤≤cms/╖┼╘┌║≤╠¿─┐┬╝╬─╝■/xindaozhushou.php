<?php
require_once(dirname(__FILE__)."/config.php");
$FILE = str_replace('\\', '/', dirname(__FILE__));
define("ROUTE", sea_ADMIN);
define("ROOT_ROUTE", preg_replace('/\/\w+$/', '', $FILE));
define("X_ADMIN", true);
define("XDZS", "新导助手：http://zzzs.xingdaoo.com/");
define("X_URL", $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/');
define("X_STATIC", "/xindaozhushou/");
define("X_PLUGIN_STATIC", X_STATIC . "static/");

if(!ROUTE){
	exit('获取文件路径失败');
}
$action = array('index', 'plugin', 'plugin_html', 'install', 'uninstall', 'plugin_install', 'plugin_uninstall', 'plugin_update', 'plugin_close', 'plugin_open', 'plugin_list');
if(in_array($_GET['action'], $action)){
    $xindaozhushou = new xindaozhushou();
    call_user_func(array($xindaozhushou, $_GET['action']));
}else{
    exit('请求错误');
}
class xindaozhushou{

    public $QC = array();
    public $EDITION = array();

	// 初始化
	public function __construct(){

		require_once(ROUTE . "/xindaozhushou/model/Allclass.php");
		$this->Allclass = new Allclass();

        $this->EDITION = array('banhao' => '6.0.1', 'shijian' => '2021-03-15');
		$this->QC['common'] = $this->shtmlspecialchars($this->loadconf('common'));
		define("X_ASLT", md5($this->QC['common']['salt'] . $this->make_token()));
		define("TONGJI", $this->Allclass->tongji());
	}

	// 默认操作
	public function index(){
		$data = array();
		$data['salt'] = X_ASLT;
		$data['edition'] = $this->EDITION;
		$data['plugin_list'] = $this->plugin_html(1);
		if(!empty($this->QC['common']['plugin_list']['url'])){
			$data['plugin_img_url'] = $this->QC['common']['plugin_list']['url'];
		}
		if(empty($this->QC['common']['plugin_list_time']) || time() - intval($this->QC['common']['plugin_list_time']) > 3600){
			$data['plugin_list_on'] = 1;
		}
		if($data){
			$data = json_encode($data);
		}else{
			$data = '{}';
        }
        include(ROUTE.'/xindaozhushou/view/index.html');
	}

	// 插件
	public function plugin(){
		$EDITION = $this->EDITION;
		$pluginid = $this->saddslashes($_GET['pluginid']);
		$mod = empty($_GET['mod']) ? 'index' : $this->saddslashes($_GET['mod']);
		define("PLUGIN_DIR", ROUTE . '/xindaozhushou/plugin/' . $pluginid . '/');
		$plugin_file = PLUGIN_DIR . $mod . '.php';
		if(is_file($plugin_file)){
			if(!empty($this->QC['common']['plugin_close']) && in_array($pluginid , $this->QC['common']['plugin_close'])){
				$data = array(
					'msg' => '插件已经关闭',
					'code' => 1,
				);
            }
			include $plugin_file;
		}else{
			$data = array(
				'msg' => '没有安装' . $pluginid . '插件，或者插件某个文件不存在',
				'code' => 1,
			);
			if(is_dir(PLUGIN_DIR)){
				$data['msg'] = '插件' . $pluginid . '，' . $mod . '文件不存在';
			}else{
				$data['msg'] = '没有安装' . $pluginid . '插件';
				if(!empty($this->QC['common']['plugin'][$pluginid])){
					unset($this->QC['common']['plugin'][$pluginid]);
					$this->loadupdate('common', $this->QC['common']);
				}
			}
			if(!empty($data['msg'])){
				$this->r_json($data['msg'], $data['code']);
			}else{
				$this->r_json('错误未知', 1);
			}
		}
	}

	// 插件
	public function plugin_html($id = 0){
		if($id == 0){
            $this->salt();
		}
		$plugin = $plugin_list = $plugin_close = array();
		if(!empty($this->QC['common']['plugin'])){
			$plugin = $this->QC['common']['plugin'];
		}
		if(!empty($this->QC['common']['plugin_close'])){
			$plugin_close = $this->QC['common']['plugin_close'];
		}
		if(!empty($this->QC['common']['plugin_list']['list'])){
			$plugin_list = $this->QC['common']['plugin_list']['list'];
			$list_anzhuang = array();
			foreach($plugin_list as $k => $v){
				$pid = $v['pluginid'];
				if(!empty($plugin[$pid])){
					$plugin_list[$k]['anzhuang'] = 1;
					if($plugin[$pid]['edition'] != $v['edition']){
						$plugin_list[$k]['gengxin'] = 1;
						$plugin_list[$k]['editions'] = $plugin[$pid]['edition'];
						$plugin_list[$k]['times'] = $plugin[$pid]['time'];
					}
					if(in_array($pid, $plugin_close)){
						$plugin_list[$k]['close'] = 0;
					}else{
						$plugin_list[$k]['close'] = 1;
					}
					unset($plugin[$pid]);
				}else{
					$plugin_list[$k]['anzhuang'] = 0;
				}
				$list_anzhuang[$k] = $plugin_list[$k]['anzhuang'];
			}
			if($plugin){
				foreach($plugin as $k => $v){
					$v['anzhuang'] = 1;
					if(in_array($v['pluginid'], $plugin_close)){
						$v['close'] = 0;
					}else{
						$v['close'] = 1;
					}
					$plugin_list[] = $v;
					$list_anzhuang[] = 1;
				}
			}
			array_multisort($list_anzhuang, SORT_DESC, $plugin_list);
		}
		if($id == 1){
			return $plugin_list;
		}else{
			// 获取插件目录判断插件是否安装
			$data = array(
				'plugin_list' => $plugin_list,
			);
			$plugin_on_ins = $this->plugin_dir();
			if($plugin_on_ins){
				$data['plugin_on_ins'] = $plugin_on_ins;
			}
			if($id == 0){
				$this->r_json('获取成功', 0, $data);
			}
		}
	}

	// 安装, 替换后台tab页面
	public function install(){
		$data = array();
		$data = $this->installs();
		$data['edition'] = $this->EDITION;
		$data['name'] = '安装-新导助手';
        $data['state'] = $data['code'] == 1 ? '安装失败' : '安装成功' . '：';
        include(ROUTE.'/xindaozhushou/view/install.html');
	}

	// 安装, 替换后台tab页面
	private function installs(){
		if(!is_file(ROUTE . '/xindaozhushou/install.lock')){

			$file = array(// 先备份文件
				'top' => ROUTE . '/templets/index.htm',
				'top_back' =>  ROUTE . '/templets/index_xdzs_back.htm',
				'left' => ROUTE . '/inc_menu.php',
				'left_back' => ROUTE . '/inc_menu_xdzs_back.php',
			);
			if(!copy($file['top'], $file['top_back']) && !is_file($file['top_back'])){
				return array(
					'msg' => '备份文件失败，请先备份：' . $file['top'] . ' 文件为：' . $file['top_back'],
					'code' => 1
				);

			}
			if(!copy($file['left'], $file['left_back']) && !is_file($file['left_back'])){
				return array(
					'msg' => '备份文件失败，请先备份：' . $file['left'] . ' 文件为：' . $file['left_back'],
					'code' => 1
				);
			}

			$tab_id = 0;

			if(is_file($file['top_back'])){

                $myfile = fopen($file['top'], "r");
				$str = fread($myfile, filesize($file['top']));
				fclose($myfile);
				$tab_li = "'system', 'xindaozhushou');";
				$str = str_replace("'system');", $tab_li, $str);
		
                $myfile1 = fopen($file['top'], "w");
				if(fwrite($myfile1, $str)){
					fclose($myfile1);
				}else{
					fclose($myfile1);
					return array(
						'msg' => '保存' . $file['top'] . ' 文件失败',
						'code' => 1
					);
				}
				$this->QC['common']['tab_id'] = $tab_id;
			}

			if(is_file($file['left_back'])){

				$myfile = fopen($file['left'], "r");
				$str = fread($myfile, filesize($file['left']));
				fclose($myfile);
				$tab_li = array(
                    'link' => "xindaozhushou.php?action=index",
                    0 => "新导",
                    1 =>"<a target='I2' href='xindaozhushou.php?action=index'>新导助手</a>",
                );
                $tab_li_str = $this->arr2str($tab_li);
                if($tab_li_str){
                    $tab_li_str = "'xindaozhushou'=>array(" . $tab_li_str . "),\n);\n\$menuedit";
                    $str = preg_replace('/\);[\s]*\$menuedit/', $tab_li_str, $str);
                }
				$myfile1 = fopen($file['left'], "w");
				if(@fwrite($myfile1, $str)){
					fclose($myfile1);
				}else{
					fclose($myfile1);
					return array(
						'msg' => '保存' . $file['left'] . ' 文件失败',
						'code' => 1
					);
				}
			}

			$this->QC['common']['salt'] = $this->str_md5();
			$this->QC['common']['install'] = md5($this->str_md5());
			$this->loadupdate('common', $this->QC['common']);
			$myfile5 = fopen(ROUTE . '/xindaozhushou/install.lock', "w");
			fclose($myfile5);

			if(!is_file(ROOT_ROUTE . "/xindaozhushou.php")){
				$myfile = fopen(ROUTE . "/xindaozhushou/xindaozhushou.php", "r");
				$str = fread($myfile, filesize(ROUTE . "/xindaozhushou/xindaozhushou.php"));
				fclose($myfile);
				preg_match('/\/(\w+)$/', ROUTE, $admin);
				if(empty($admin[1])){
					return array(
						'msg' => '前台安装失败：001',
						'code' => 1
					);
				}
				$md5s = $this->str_md5();
				$myfile6 = fopen(ROOT_ROUTE . '/xindaozhushou/config_' . $md5s . ".php", "w");
				if(@fwrite($myfile6, "<?php return '". $admin[1] ."';")){
					fclose($myfile6);
				}else{
					fclose($myfile6);
					return array(
						'msg' => '前台安装失败：002',
						'code' => 1
					);
				}
				$str = str_replace("xindaozhushou/config.php", 'xindaozhushou/config_' . $md5s . '.php', $str);
				$myfile5 = fopen(ROOT_ROUTE . "/xindaozhushou.php", "w");
				if(@fwrite($myfile5, $str)){
					fclose($myfile5);
				}else{
					fclose($myfile5);
					return array(
						'msg' => '前台安装失败：003',
						'code' => 1
					);
				}
			}

			return array(
				'msg' => '安装成功，刷新后台即可看见菜单',
				'code' => 0
			);
		}else{
			return array(
				'msg' => '请先删除插件目录 install.lock 文件',
				'code' => 1
			);
		}
	}

	// 卸载
	public function uninstall(){
		$this->salt();
		$data = array();
		$data = $this->uninstalls();
		if(!empty($data['msg'])){
			$this->r_json($data['msg'], $data['code']);
		}else{
			$this->r_json('错误未知', 1);
		}
	}

	// 卸载
	private function uninstalls(){
		if(!$this->salt(1)){
			return array(
				'msg' => '卸载失败，刷新试试',
				'code' => 1
			);
		}
        $file = array(// 先备份文件
            'top' => ROUTE . '/templets/index.htm',
            'top_back' =>  ROUTE . '/templets/index_xdzs_back.htm',
            'left' => ROUTE . '/inc_menu.php',
            'left_back' => ROUTE . '/inc_menu_xdzs_back.php',
        );
		if(is_file($file['top_back'])){ // 删除选项卡文件，回源备份
			unlink($file['top']);
			if(copy($file['top_back'], $file['top'])){
				unlink($file['top_back']);
			}
		}
		if(is_file($file['left_back'])){ // 删除左侧文件，回源备份
			unlink($file['left']);
			if(copy($file['left_back'], $file['left'])){
				unlink($file['left_back']);
			}
		}
		if(is_dir(ROUTE . '/xindaozhushou')){ // 删除插件目录
			$this->deldir(ROUTE . '/xindaozhushou');
		}
		if(is_dir('../xindaozhushou')){ // 删除插件静态文件
			$this->deldir('../xindaozhushou');
		}
		if(is_file('../xindaozhushou.php')){ // 删除更目录插件文件
			unlink('../xindaozhushou.php');
		}
		if(is_file(ROUTE . '/xindaozhushou.php')){ // 删除插件文件
			unlink(ROUTE . '/xindaozhushou.php');
		}
		if(is_file(ROUTE . '/img/xindaozhushou.png')){ // 删除插件图标
			unlink(ROUTE . '/img/xindaozhushou.png');
		}
		return array(
			'msg' => '卸载成功',
			'code' => 1
		);
	}

	// 安装插件
	public function plugin_install(){
		$this->salt();
		$plugin_name = $this->saddslashes($_POST['pluginid']);
		$no_plugin = !empty($_POST['no_plugin']) ?  intval($_POST['no_plugin']) : 0;
		define("PLUGIN_DIR_INS", ROUTE . '/xindaozhushou/plugin/' . $plugin_name . '/');
		$data = array();
		$data = $this->plugin_installs($plugin_name, $no_plugin);
		if(!empty($data['msg'])){
			$this->r_json($data['msg'], $data['code']);
		}else{
			$this->r_json('错误未知', 1);
		}
	}

	// 安装插件
	private function plugin_installs($plugin_name, $no_plugin = 0){

		$outPath = ROUTE . "/xindaozhushou/plugin/";

		if($no_plugin == 1){
			$zips_data = is_dir($outPath . $plugin_name);
		}else{
			$save_dir = ROUTE . '/xindaozhushou/download/';
			$zip_plugin_name = $plugin_name . '.zip';
			if(is_file($save_dir . $zip_plugin_name)){
				$file_arr = array(
					'save_path' => $save_dir . $zip_plugin_name
				);
			}else{
				$file_arr = $this->getFile('http://ziyuanapi.xingdaoo.com/plugin/download/hy/' . $zip_plugin_name,  $zip_plugin_name);
			}
			if((!empty($file_arr['size']) && intval($file_arr['size']) < 10) || !(!empty($file_arr['save_path']) && is_file($file_arr['save_path']))){
				return array(
					'msg' => '安装失败：下载插件失败',
					'code' => 1
				);	
			}
			$zips_data = $this->zips($file_arr['save_path'], $outPath);
		}

		if($zips_data === true){
			$path = $outPath . $plugin_name . '/config.php';
			if(!is_file($path)){
				return array(
					'msg' => '安装失败：插件没有配置文件',
					'code' => 1
				);
			}
			$config = include($path);
			if(!is_array($config)){
				return array(
					'msg' => '安装失败：插件配置文件格式错误',
					'code' => 1
				);
			}

			$arr = array("name", "pluginid", "edition", "time", "description", "author", "url");
			foreach($config as $k => $v){
				if(!in_array($k, $arr)){
					return array(
						'msg' => '安装失败：插件配置文件有未知参数',
						'code' => 1
					);
				}
				if(is_string($v)){
					$config[$k] = $this->shtmlspecialchars($v);
				}else{
					return array(
						'msg' => '安装失败：插件配置文件参数格式错误',
						'code' => 1
					);
				}
			}

			if(is_dir($outPath . $plugin_name . '/static')){
				$this->copydir($plugin_name . '/static', ".." . X_PLUGIN_STATIC . $plugin_name);
			}

			$config = $this->shtmlspecialchars($config);
			$this->QC['common']['plugin'][$plugin_name] = $config;
			$this->loadupdate('common', $this->QC['common']);

			$outPath .= $plugin_name . '/install.php';
			if(is_file($outPath)){
				include $outPath;
			}
			$this->left_html();
			unlink($file_arr['save_path']);
			return array(
				'msg' => '安装成功',
				'code' => 0
			);
		}else{
			if(is_array($zips_data)){
				return $zips_data;
			}else{
				if($zips_data == 19){
					if(!empty($file_arr['save_path']) && is_file($file_arr['save_path'])){
						unlink($file_arr['save_path']);
					}
				}
			}
			return array(
				'msg' => '解压插件文件失败，解压错误代码：' . $zips_data,
				'code' => 1
			);
		}
	}

	// 卸载插件
	public function plugin_uninstall(){
		$this->salt();
		$data = array();
		$plugin_name = $this->saddslashes($_POST['pluginid']);
		$data = $this->plugin_uninstalls($plugin_name);
		if(!empty($data['msg'])){
			$this->r_json($data['msg'], $data['code']);
		}else{
			$this->r_json('错误未知', 1);
		}
	}

	// 卸载插件
	private function plugin_uninstalls($plugin_name){
		$pluginPath = ROUTE . '/xindaozhushou/plugin/' . $plugin_name;
		if(is_file($pluginPath . '/uninstall.php')){
			include $pluginPath . '/uninstall.php';
		}
		if(is_dir($pluginPath)){
			
			if(is_dir('..' . X_PLUGIN_STATIC . $plugin_name)){
				$this->deldir('..' . X_PLUGIN_STATIC . $plugin_name);
			}

			if(is_dir(ROUTE . '/xindaozhushou/config/' . $plugin_name)){
				$this->deldir(ROUTE . '/xindaozhushou/config/' . $plugin_name);
			}

			if(!empty($this->QC['common']['plugin_close']) && in_array($plugin_name, $this->QC['common']['plugin_close'])){
				$id = array_search($plugin_name, $this->QC['common']['plugin_close']);
				unset($this->QC['common']['plugin_close'][$id]);
				$this->loadupdate('common', $this->QC['common']);
			}

			$this->deldir($pluginPath);
			if(!empty($this->QC['common']['plugin'][$plugin_name])){
				unset($this->QC['common']['plugin'][$plugin_name]);
				$this->loadupdate('common', $this->QC['common']);
				$this->left_html();
			}
			return array(
				'msg' => '卸载成功',
				'code' => 0
			);
		}else{
			return array(
				'msg' => '插件不存在',
				'code' => 1
			);
		}
	}

	// 更新插件
	public function plugin_update(){
		$this->salt();
		$data = array();
		$plugin_name = $this->saddslashes($_POST['pluginid']);
		$data = $this->plugin_updates($plugin_name);
		if(!empty($data['msg'])){
			$this->r_json($data['msg'], $data['code']);
		}else{
			$this->r_json('错误未知', 1);
		}
	}

	// 更新插件
	private function plugin_updates($plugin_name){
		$file_arr = $this->getFile('http://ziyuanapi.xingdaoo.com/plugin/download/hy/' . $plugin_name . '.zip',  $plugin_name . '.zip');
		if(!empty($file_arr['save_path']) && is_file($file_arr['save_path'])){
			$outPath = ROUTE . "/xindaozhushou/plugin/";
			$zips_data = $this->zips($file_arr['save_path'], $outPath);
			if($zips_data === true){
				$path = $outPath . $plugin_name;
				if(!is_file($path . '/config.php')){
					return array(
						'msg' => '更新失败：插件没有配置文件',
						'code' => 1
					);
				}
				$config = include($path . '/config.php');
				if(!is_array($config)){
					return array(
						'msg' => '更新失败：插件配置文件格式错误',
						'code' => 1
					);
				}

				if(is_dir($outPath . $plugin_name . '/static')){
					$this->copydir($plugin_name . '/static', ".." . X_PLUGIN_STATIC . $plugin_name);
				}

				$outPath .= '/update.php';
				if(is_file($outPath)){
					include $outPath;
				}
				$config = $this->shtmlspecialchars($config);
				$this->QC['common']['plugin'][$plugin_name] = $config;
				$this->loadupdate('common', $this->QC['common']);
				return array(
					'msg' => '更新成功',
					'code' => 0
				);
			}else{
				if(is_array($zips_data)){
					return $zips_data;
				}
				return array(
					'msg' => '解压插件文件失败，解压错误代码：' . $zips_data,
					'code' => 1
				);
			}

		}else{
			return array(
				'msg' => '更新失败，下载文件失败',
				'code' => 1
			);
		}
	}

	// 关闭插件
	public function plugin_close(){
		$this->salt();
		$plugin_name = $this->saddslashes($_POST['pluginid']);
		if(!in_array($plugin_name, $this->QC['common']['plugin_close'])){
			$this->QC['common']['plugin_close'][] = $plugin_name;
			$this->loadupdate('common', $this->QC['common']);
			$this->r_json('关闭成功', 0);
			$this->left_html();
			return;
		}
		$this->r_json('已经关闭了', 1);
	}

	// 开启插件
	public function plugin_open(){
		$this->salt();
		$plugin_name = $this->saddslashes($_POST['pluginid']);
		if(in_array($plugin_name, $this->QC['common']['plugin_close'])){
			$id = array_search($plugin_name, $this->QC['common']['plugin_close']);
			unset($this->QC['common']['plugin_close'][$id]);
			$this->loadupdate('common', $this->QC['common']);
			$this->r_json('开启成功', 0);
			$this->left_html();
			return;
		}
		$this->r_json('已经开启了', 1);
	}

	// 获取插件列表
	public function plugin_list(){
		$this->salt();
		if(empty($this->QC['common']['plugin_list_time']) || time() - $this->QC['common']['plugin_list_time'] > 3600){
			$list = $this->geturl('http://ziyuanapi.xingdaoo.com/pluginapi?cms=hy');
			if(!empty($list['data'])){
				$this->QC['common']['plugin_list'] = $list['data'];
				$this->plugin_html(2);
				$this->r_json('更新插件列表成功', 0);
			}else{
				$this->r_json('更新插件列表失败', 1);
			}
			$this->QC['common']['plugin_list_time'] = time();
			$this->loadupdate('common', $this->QC['common']);
		}
	}

	protected function salt($id = 0){
		if(!empty($_POST['veri']) && $_POST['veri'] == X_ASLT){
			return true;
		}
		if($id) return false;
		exit('行为操作，验证失败，' . XDZS);
	}

	// 解压文件
	private function zips($save_path, $outPath){
		return $this->Allclass->zips($save_path, $outPath);
	}

	// 复制文件
	private function copydir($dir, $toDir){
		return $this->Allclass->copydir($dir, $toDir);
	}

    // 数组转字符串
    protected function arr2str($arr, $t = 1){
        return $this->Allclass->arr2str($arr, $t);
    }

    protected function saddslashes($string, $force = 0){
        return $this->Allclass->saddslashes($string, $force);
    }

    protected function shtmlspecialchars($string) {
        return $this->Allclass->shtmlspecialchars($string);
    }

    protected function sintval($str) {
        return $this->Allclass->sintval($str);
	}
	
	// 更新插件左侧导航
	private function left_html(){
		$file = ROUTE . '/inc_menu.php';
		if(is_file($file)){

            $tab_li = array(
                'link' => "xindaozhushou.php?action=index",
                0 => "新导",
                1 => "<a target='I2' href='xindaozhushou.php?action=index'>新导助手</a>",
            );

			foreach($this->QC['common']['plugin'] as $k => $config){
				if(!empty($this->QC['common']['plugin_close']) && in_array($k, $this->QC['common']['plugin_close'])){
					continue;
				}
				if(!empty($config['name']) && !empty($config['pluginid'])){
					$tab_li[] = "<a target='I2' href='xindaozhushou.php?action=plugin&pluginid=".$config['pluginid']."'>".$config['name']."</a>";
				}
			}

            $myfile = fopen($file, "r");
            $str = fread($myfile, filesize($file)); 
            $tab_li_str = $this->arr2str($tab_li);
            if($tab_li_str){
                $tab_li_str = "xindaozhushou'=>array(" . $tab_li_str . "),\n);\n\$menuedit";
                $str = preg_replace('/xindaozhushou(.|\n)*?\$menuedit/', $tab_li_str, $str);
            }
			$myfile1 = fopen($file, "w");
			@fwrite($myfile1, $str);
			fclose($myfile1);
		}
	}

	protected function r_json($msg = '', $code = 1, $data = null){

		if($msg || $data || $code = 0){
			echo json_encode(array(
				'code' => $code,
				'msg' => $msg,
				'data' => $data
			));
		}else{
			echo '{"code": '. $code .'}';
		}
	}

	protected function dir_emptys($path){
		$path_handle = opendir($path);
		readdir($path_handle);
		readdir($path_handle);
		return (bool)readdir($path_handle);
	}

    protected function make_token($length = 16){
		if(!empty($this->QC['common']['token']['token']) && !empty($this->QC['common']['token']['time']) && time() - intval($this->QC['common']['token']['time']) < 160000){
			 return $this->QC['common']['token']['token'];
		}
		$token = $this->str_md5($length);
		$this->QC['common']['token'] = array(
			'token' => $token,
			'time' => time()
		);
		$this->loadupdate('common', $this->QC['common']);
		return $token;
    }

	// 获取随机字符串
	protected function str_md5($length = 16){
        return $this->Allclass->str_md5($length);
	}

	// 加载配置文件
	private function loadconf($path){
		$path = $this->saddslashes($path);
		$path = ROUTE . '/xindaozhushou/config/' . $path .'.php';
		if (is_file($path)) {
			$config = include($path);
			if(is_array($config)){
				return $this->shtmlspecialchars($config);
			}
		}
		return array();
	}

	// 加载插件配置
	protected function loadconf_plugin($path, $zhushou = false){
		if(strpos($path, ':')){
			$path = str_replace(':', '/', $path);
		}else{
			if($zhushou){
				$path = $path;
			}else{
				$path = $path . "/config";
			}
		}
		return $this->loadconf($path);
	}

	// 更新配置
	private function loadupdate($path, $data){
		$path = $this->saddslashes($path);
		$dir = ROUTE . '/xindaozhushou/config/';
		$path = $dir . $path . ".php";
		$data = $this->shtmlspecialchars($data);
		$data = $this->saddslashes($data);
		$str = "<?php\nreturn array(\n";
		$str .= $this->arr2str($data);
		$str .= ");";
		if (file_put_contents($path, $str)) {
			return true;
		} else {
			return false;
		}
	}
	
	// 更新插件配置
	protected function loadupdate_plugin($path, $data){
		if(!$path){
			return false;
		}
		$dir = ROUTE . '/xindaozhushou/config/';
		if(strpos($path, ':')){
			$dir .= explode(":", $path)[0];
			$path = str_replace(':', '/', $path);
		}else{ 
			$path .= '/config'; // 默认插件配置文件
		}
		if (!is_dir($dir)) {
			mkdir(iconv("UTF-8", "GBK", $dir), 0777, true);
		}
		return $this->loadupdate($path, $data);
	}

	// 获取插件文件
	private function getFile($url, $filename = ''){
		return $this->Allclass->getFile($url, $filename);
	}

	// 获取API接口
	protected function geturl($url, $type = 'json'){
		return $this->Allclass->geturl($url, $type);
	}

	// 删除目录
	protected function deldir($path){
		return $this->Allclass->deldir($path);
	}

	// 获取未安装插件列表
	private function plugin_dir(){
		$path = ROUTE . '/xindaozhushou/plugin/';
		$arr = array();
		if (is_dir($path)) {
			$plugin = $this->QC['common']['plugin'];
			$list = scandir($path);
			foreach ($list as $val) {
				if ($val != "." && $val != "..") {
					if (is_dir($path . $val)) {
						if(empty($plugin[$val]) && is_file($path . $val . '/config.php')){
							$config = $this->saddslashes(include($path . $val . '/config.php'));
							if($config['pluginid'] == $val){
								$config['anzhuang'] = 0;
								$config['bendi'] = 1;
								$arr[] = $config;
							}
						}
					}
				}
			}
		}
		return $arr;
	}
}
?>