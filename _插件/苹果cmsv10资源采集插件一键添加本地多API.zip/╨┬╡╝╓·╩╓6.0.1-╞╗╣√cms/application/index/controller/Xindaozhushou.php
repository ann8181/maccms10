<?php
namespace app\index\controller;
use app\xindaozhushou\model\Allclass;
use think\Db;

class Xindaozhushou extends Base{

	private $Allclass;

	// 初始化
	public function __construct(){
		$this->Allclass = new Allclass();
		define("ROUTE", str_replace("/index/controller", "", str_replace('\\', '/', dirname(__FILE__))));
		define("X_ADMIN", false);
		define("XDZS", "新导助手：http://zzzs.xingdaoo.com/，");
		define("X_URL", $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/');
		define("X_STATIC", "/static/xindaozhushou/");
		define("X_PLUGIN_STATIC", X_STATIC . "static/");
		define("TONGJI", $this->Allclass->tongji());
		
	}

	// 插件
	public function plugin(){
		$EDITION = array('banhao' => '6.0.1', 'shijian' => '2021-03-15');
		$pluginid = $this->saddslashes($_GET['pluginid']);
		$mod = empty($_GET['mod']) ? 'index' : $this->saddslashes($_GET['mod']);
		define("PLUGIN_DIR", ROUTE . '/xindaozhushou/plugin/' . $pluginid . '/');
		$plugin_file = PLUGIN_DIR . $mod . '.php';
		if(is_file($plugin_file)){
			include $plugin_file;
		}else{
			$this->r_json('没有安装' . $pluginid . '插件，或者插件某个文件不存在', 1);
		}
	}

	protected function r_json($msg = '', $code = 1, $data = null){
		echo json_encode(array(
			'code' => $code,
			'msg' => $msg,
			'data' => $data
		));
	}

    protected function saddslashes($string, $force = 0){
        return $this->Allclass->saddslashes($string, $force);
    }

    protected function shtmlspecialchars($string) {
        return $this->Allclass->shtmlspecialchars($string);
    }

    protected function sintval($str) {
		return $this->Allclass->sintval($str);
    }

	// 获取表前缀
	protected function table($table){
		$config = config();
		if(!empty($config['maccms']['db']['tablepre'])){
			return $config['maccms']['db']['tablepre'] . $table;
		}
		return $table;
	}

	// 数据库操作
	protected function query($sql){
		$met = false;
		foreach(array("update", "insert", "delete") as $k => $v){
			if(stripos($sql, $v) === 0){
				$met = true;
				break;
			}
		}
		if($met){
			return Db::execute($sql);
		}else{
			return Db::query($sql);
		}
	}

	// 取查询第一条
	protected function query_first($sql){
		$data = $this->query($sql);
		if(!empty($data[0])){
			return $data[0];
		}
		return false;
	}

	// 加载配置文件
	private function loadconf($path){
		$path = $this->saddslashes($path);
		$path = ROUTE . '/xindaozhushou/config/' . $path .'.php';
		if (is_file($path)) {
			$config = include($path);
			if(is_array($config)){
				return $this->shtmlspecialchars($config);
			}
		}
		return array();
	}

	// 加载插件配置
	protected function loadconf_plugin($path, $zhushou = false){
		if(strpos($path, ':')){
			$path = str_replace(':', '/', $path);
		}else{
			if($zhushou){
				$path = $path;
			}else{
				$path = $path . "/config";
			}
		}
		return $this->loadconf($path);
	}

	// 更新配置
	private function loadupdate($path, $data){
		$path = $this->saddslashes($path);
		$dir = ROUTE . '/xindaozhushou/config/';
		$path = $dir . $path . ".php";
		$data = $this->shtmlspecialchars($data);
		$data = $this->saddslashes($data);
		$str = "<?php\nreturn array(\n";
		$str .= $this->arr2str($data);
		$str .= ");";
		if (file_put_contents($path, $str)) {
			return true;
		} else {
			return false;
		}
	}

	// 更新插件配置
	protected function loadupdate_plugin($path, $data){
		if(!$path){
			return false;
		}
		$dir = ROUTE . '/xindaozhushou/config/';
		if(strpos($path, ':')){
			$dir .= explode(":", $path)[0];
			$path = str_replace(':', '/', $path);
		}else{ 
			$path .= '/config'; // 默认插件配置文件
		}
		if (!is_dir($dir)) {
			mkdir(iconv("UTF-8", "GBK", $dir), 0777, true);
		}
		return $this->loadupdate($path, $data);
	}

    // 数组转字符串
    protected function arr2str($arr, $t = 1){
        return $this->Allclass->arr2str($arr, $t); 
	}
	
	protected function str_md5($length = 16){
        return $this->Allclass->str_md5($length);
	}
}
?>