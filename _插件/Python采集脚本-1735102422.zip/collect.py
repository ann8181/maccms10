#!/usr/bin/Python
# -*- coding: utf-8 -*-
'''
#-------------------------------------------
#
#	@Project Name : 资源站API数据采集脚本
#
#	@File Name    : collect.py
#
#	@Author       : www.mycj.pro
#
#	@Version      : 1.0.0
#   
#   @introduce    : 脚本需配合萌芽采集插件使用，若对脚本有优化建议，请联系我们反馈
#
#-------------------------------------------
'''
import requests,time,json,os,sys,yaml
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed 

######################x# 下方代码不懂请勿修改 ################################

start = time.perf_counter();
pool_connections = 100  
pool_maxsize = 1000  
session = requests.Session();
session.mount('http://', requests.adapters.HTTPAdapter(pool_connections=pool_connections, pool_maxsize=pool_maxsize));
session.mount('https://', requests.adapters.HTTPAdapter(pool_connections=pool_connections, pool_maxsize=pool_maxsize));
headers = {  
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.95 Safari/537.36'
    }; 
globals_dict = {};
success_num = 0;
error_num = 0;

def request_url(url, page=1):
    global success_num, error_num, globals_dict
    url = f"{url}&pg={page}";
    print(f"{globals_dict['des']} 正在采集第 {page} 页，请求URL：{url}");   
    data = None;  
    try:
        res = session.get(url, headers=headers, timeout=30);  
        try:  
            data = res.json();
        except json.JSONDecodeError:  
            pass  
        try:  
            root = ET.fromstring(res.text);
            data = xml_to_dict(root);
        except ET.ParseError:  
            pass  
        if data is not None and data.get("code") == 1:  
            if page == 1 :
                return data;
            else:
                return post_data(data);  
    except requests.RequestException as e:
        print(f"请求URL：{url} 异常报错：\n{e}")
    return None;

def post_data(data):
    global success_num, error_num, globals_dict
    data_url = f"{domain_url}/api.php/autotasks/update_data";
    for v in data['list']:
        v['pass'] = Apipass;
        v['param'] = json.dumps(globals_dict);
        del v['type_id'];
        try:  
            response = session.post(data_url, data=v, headers=headers, timeout=30); 
            ret = response.json();
            log = f"{globals_dict['des']} 第{data['page']}页\n视频名称：{v['vod_name']} {v['vod_remarks']}\n分类名称：{v['type_name']}\n入库提示：{ret['msg']}\n";
            if "ok" in ret.get("msg"):
                success_num = success_num + 1;
            elif ret.get("code") > 3000:
                print(f"发布入库失败，请根据提示做检查：{ret['msg']}");  
                os._exit(1);
            else:
                error_num = error_num + 1;
            print(log); 
        except requests.exceptions.RequestException as e:  
            error_num = error_num + 1;
            print(f"{globals_dict['des']}\nPOST请求入库失败，错误内容: \n{e}"); 
  
def collect(arr):
    global success_num, error_num
    tasks_des = arr.get("des");
    print(f"开始采集任务：{tasks_des}");  
    cjurl = arr.get("cjurl");
    data = request_url(cjurl);
    if data is not None and data.get("code") == 1:
        total = int(data.get("total"));
        limit = int(data.get("limit"));
        page = int(data.get("page"));
        total_pages = total // limit 
        if total % limit > 0:
            total_pages += 1
        print(f"{tasks_des} 待采集总数据：{total} 每页数据：{limit} 总页码：{total_pages}");  
        post_data(data);
        if total_pages>1:
            with ThreadPoolExecutor(max_workers=max_workers) as executor:  
                future_to_page = {executor.submit(request_url, cjurl, page): page for page in range(2, total_pages + 1)}  
                for future in as_completed(future_to_page):  
                    page = future_to_page[future]  
                    try:  
                        future.result()  
                    except Exception as exc:  
                        print(f"多线程请求，发生了异常: {exc}")  

        log = f"{tasks_des} 总数据：{total} 入库成功：{success_num} 采集跳过未入库数：{error_num}\n";
    else:
        log = "未获取到数据，结束该任务\n";
    return log;

def get_url(url):
    try:
        res = session.get(url, headers=headers, timeout=30); 
        if res.status_code == 200:
            return res.json();
        else:
            print(f"请求URL： {url} 失败，返回内容：\n{res.text}")
    except requests.RequestException as e:
        print(f"请求URL： {url} 异常报错：\n{e}")
    return None;

def vod_xml_replace(url):
    array_url = []
    arr_ji = url.replace('||', '//').split('#')
    for key, value in enumerate(arr_ji):
        urlji = value.split('$')
        if len(urlji) > 1:
            array_url.append(f'{urlji[0]}${urlji[1].strip()}')
        else:
            array_url.append(urlji[0].strip())
    return '#'.join(array_url)

def xml_to_dict(root):  
    list_element = root.find('list')
    array_data = []
    for video in root.findall('.//video'):
        video_data = {
            'vod_time': video.find('last').text if video.find('last') is not None else '',
            'vod_id': video.find('id').text if video.find('id') is not None else '',
            'type_id': video.find('tid').text if video.find('tid') is not None else '',
            'vod_name': video.find('name').text if video.find('name') is not None else '',
            'vod_sub': video.find('subname').text if video.find('subname') is not None else '',
            'type_name': video.find('type').text if video.find('type') is not None else '',
            'vod_pic': video.find('pic').text if video.find('pic') is not None else '',
            'vod_lang': video.find('lang').text if video.find('lang') is not None else '',
            'vod_area': video.find('area').text if video.find('area') is not None else '',
            'vod_year': video.find('year').text if video.find('year') is not None else '',
            'vod_serial': video.find('state').text if video.find('state') is not None else '',
            'vod_remarks': video.find('note').text if video.find('note') is not None else '',
            'vod_actor': video.find('actor').text if video.find('actor') is not None else '',
            'vod_director': video.find('director').text if video.find('director') is not None else '',
            'vod_content': '',
            'vod_play_from': [],
            'vod_play_url': [],
            'vod_play_server': [],
            'vod_play_note': []
        }
        if video.find('des').text is not None:
            video_data['vod_content'] = video.find('des').text.strip(); 
        
        dl_elements = video.findall('dl/dd')
        count = len(dl_elements)
        for i in range(count):
            dd_element = dl_elements[i]
            flag = dd_element.get('flag', '')
            url = vod_xml_replace(dd_element.text)
            server = 'no'
            note = ''
            video_data['vod_play_from'].append(flag)
            video_data['vod_play_url'].append(url)
            video_data['vod_play_server'].append(server)
            video_data['vod_play_note'].append(note)

        if not dl_elements:
            video_data['vod_play_from'].append('')
            video_data['vod_play_url'].append('')
            video_data['vod_play_server'].append('')
            video_data['vod_play_note'].append('')

        video_data['vod_play_from'] = '$$$'.join(video_data['vod_play_from'])
        video_data['vod_play_url'] = '$$$'.join(video_data['vod_play_url'])
        video_data['vod_play_server'] = '$$$'.join(video_data['vod_play_server'])
        video_data['vod_play_note'] = '$$$'.join(video_data['vod_play_note'])        
        array_data.append(video_data)

    result = {
        "code": 1,
        "msg": "xml数据列表",
        "page": list_element.get('page'),
        "pagecount": list_element.get('pagecount'),
        "limit": list_element.get('pagesize'),
        "total": list_element.get('recordcount'),
        'list': array_data
    }
    return result 
    
if __name__ == "__main__":
    print(f"当前Python 版本：{sys.version}");
    current_dir = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(current_dir, 'config.yaml')
    datas = None;
    with open(config_path,'r',encoding='utf-8') as ff:    
        try:
            datas = yaml.safe_load(ff);
        except yaml.YAMLError as exc:
            print(f"读取配置错误：{exc}");
    if datas is not None:
        domain_url = datas.get('domain_url');
        token = datas.get('token');
        Apipass = datas.get('Apipass');
        max_workers = datas.get('max_workers');
        tasks_url = f"{domain_url}/api.php/autotasks/index?token={token}";
        tasks_list = get_url(tasks_url);
        if tasks_list.get('code') == 1:
            loger = "\n";
            for value in tasks_list.get('tasks'):
                globals_dict = value;
                loger+= collect(value);
            loger+="\n采集跳过未入库的,有可能是分类未绑定,或数据已存在不需要更新的,就会跳过不入库";
            print(loger);
        else:
            print(f"{tasks_list.get('msg')}\n");

now_time = time.strftime('%Y-%m-%d %H:%M:%S');
end = time.perf_counter() 
elapsed_time = end-start
hours = int(elapsed_time // 3600)  
minutes = int((elapsed_time % 3600) // 60)  
seconds = int(elapsed_time % 60)   
if hours > 0:  
    print(f"当前时间：{now_time} 本次任务耗时：{hours}小时{minutes}分{seconds}秒")  
elif minutes > 0:  
    print(f"当前时间：{now_time} 本次任务耗时：{minutes}分{seconds}秒")  
else:  
    print(f"当前时间：{now_time} 本次任务耗时：{seconds}秒")